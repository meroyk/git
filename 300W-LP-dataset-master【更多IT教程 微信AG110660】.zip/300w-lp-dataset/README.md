# 300W-LP-dataset

300W-LP 数据下载：

链接：https://pan.baidu.com/s/1XGHrHdZzvLw1TNcNNmuKkw 
提取码：bwus 
复制这段内容后打开百度网盘手机App，操作更方便哦